A library to assist in creating guis with chattriggers modules
